import os, sys, pandas as pd

# energy difference function
def addEnergyDifferencesToDataframe(df, cols):
    for col in cols:
        df[f'{col}Diff'] = df[f'{col}DimerOptimize'] - df[f'{col}Monomer']
    return df

# read the command line arguments
file_to_merge = sys.argv[1]
input_file = sys.argv[2]
output_file = sys.argv[3]
output_dir = sys.argv[4]

os.makedirs(name=output_dir, exist_ok=True)

# read the input file and the file to merge as dataframes
df = pd.read_csv(input_file, sep=',', dtype={'Interface': str})
df_to_merge = pd.read_csv(file_to_merge, sep=',', dtype={'Interface': str, 'replicateNumber': str})

# rename the Directory and replicateNumber columns
df.rename(columns={'Directory': 'Optimized_Directory', 'replicateNumber': 'Optimized_replicateNumber', 'Total': 'Optimized_Total'}, inplace=True)

# keep only the 3 to 17 str in the Sequence column
df_to_merge['Sequence'] = df_to_merge['Sequence'].str[3:18]
cols = ['WTSequence', 'Sequence', 'Design', 'replicateNumber', 'Directory', 'Total', 'VDWDiff', 'HBONDDiff', 'IMM1Diff','VDWRepackDiff', 'HBONDRepackDiff', 'IMM1RepackDiff']

# Below is a quick fix to be able to use this with mutant data from the pdboptimization analysis as well
# check if there is a WTSequence column in the df_to_merge
#print(df_to_merge.columns)
#print(df.columns)
#if 'WTSequence' in df_to_merge.columns:
#    df['WTSequence'] = df['Sequence']
#    cols = ['WTSequence', 'Sequence', 'Design', 'replicateNumber', 'Directory', 'Total', 'VDWDiff', 'HBONDDiff', 'IMM1Diff','VDWRepackDiff', 'HBONDRepackDiff', 'IMM1RepackDiff']
if all(col in df_to_merge.columns for col in cols):
    df_to_merge = df_to_merge[cols]
else:
    # get the columns that are present
    cols = [col for col in cols if col in df_to_merge.columns]
    df_to_merge = df_to_merge[cols]

print(df.columns)
print(df_to_merge.columns)
# merge that data with the data to merge with any matching columns
df = pd.merge(df, df_to_merge[cols], on='Sequence', how='left')

# add energy differences to the dataframe
cols = ['VDW', 'HBOND', 'IMM1']
df = addEnergyDifferencesToDataframe(df, cols)

# add LLL to the beginning of the sequence and ILI to the end of the sequence
df['Sequence'] = 'LLL' + df['Sequence'] + 'ILI'

# rid of any without a WTSequence
df = df[df['WTSequence'].notnull()]

# output the dataframe to a csv file without the index
df.to_csv(f'{output_dir}/{output_file}.csv', index=False)