import os, sys, pandas as pd, matplotlib.pyplot as plt, matplotlib, numpy as np, argparse
from scipy import stats

# initialize the parser
parser = argparse.ArgumentParser(description='Plots the KDE of Angle vs Distance w/ additional design data as input')

# add the necessary arguments
parser.add_argument('-kdeFile','--kdeFile', type=str, help='the input kde file')
parser.add_argument('-dataFile','--dataFile', type=str, help='the input data file csv file')
# add the optional arguments
parser.add_argument('-outDir','--outputDir', type=str, help='the output directory')

# extract the arguments into variables
args = parser.parse_args()
kdeFile = args.kdeFile
dataFile = args.dataFile
# default values for the optional arguments
outputDir = os.getcwd()
# if the optional arguments are not specified, use the default values
if args.outputDir is not None:
    outputDir = args.outputDir
    os.makedirs(outputDir, exist_ok=True)

# Functions
def plotGeomKde(df_kde, df_data, dataColumn, outputDir, xAxis, yAxis, roundToNearest=5, minY=-100000, maxY=-100000, reverseColormap=False):
    # get the x and y axes data to be plotted from the dataframe
    x = df_data.loc[:, xAxis]
    y = df_data.loc[:, yAxis]
    energies = df_data[dataColumn].values
    # check if the energies is empty
    if len(energies) == 0:
        return # no data to plot
    # get the kde plot for the geometry data
    kdeZScores = getKdePlotZScoresplotKdeOverlayForDfList(df_kde, 'Distance', 'Angle')
    # if the min and max y values are not specified, calculate them from the data
    if minY == -100000:
        minY = int(np.floor(np.min(energies)/5)*roundToNearest)
        maxY = int(np.ceil(np.max(energies)/5)*roundToNearest)
    # plot the kde plot with an overlay of the input dataset   
    plotKdeOverlay(kdeZScores, x, y, energies, dataColumn, outputDir, minY, maxY, reverseColormap)

def plotKdeOverlay(kdeZScores, xAxis, yAxis, data, dataColumn, outputDir, minY, maxY, reverseColormap):
    # Plotting code below
    fig, ax = plt.subplots()
    # plotting labels and variables 
    plt.grid(False)
    plt.xlabel("Distance (Å)")
    plt.ylabel("Angle (°)")
    plt.title("")
    # Setup for plotting output
    plt.rc('font', size=10)
    plt.rc('xtick', labelsize=10)
    plt.rc('ytick', labelsize=10)
    # hardcoded variable set up for plot limits
    xmin, xmax, ymin, ymax = 6, 12, -100, 100
    # setup kde plot for original geometry dataset
    ax.use_sticky_edges = False
    q = ax.imshow(np.rot90(kdeZScores), cmap=plt.cm.Blues,
        extent=[xmin, xmax, ymin, ymax], aspect="auto")
    # Plot datapoints onto the graph with fluorescence as size
    # get colormap shades of green
    cmap = plt.cm.Reds
    if reverseColormap:
        cmap = cmap.reversed()
    
    # flip the data so that the min is at the top of the colorbar
    norm = matplotlib.colors.Normalize(vmin=minY, vmax=maxY) 
    ax.scatter(xAxis, yAxis, c=cmap(norm(data)), s=10, alpha=0.5)
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    # normalize the fluorescent data to the range of the colorbar
    sm.set_array([])  # only needed for matplotlib < 3.1
    fig.colorbar(sm)
    # add the number of datapoints to the plot
    plt.text(xmin-1, ymax+12, "# Sequences = " + str(len(xAxis)), fontsize=10)
    ax.set_xlim([xmin, xmax])
    ax.set_ylim([ymin, ymax])
    ax.set_xticks([6,7,8,9,10,11,12])
    axes = plt.gca()

    # output the number of sequences in the dataset onto plot
    plt.tight_layout()
    plt.savefig(f'{outputDir}/kdeOverlay_{dataColumn}.png', bbox_inches='tight', dpi=150)
    plt.savefig(f'{outputDir}/kdeOverlay_{dataColumn}.svg', bbox_inches='tight', dpi=150)
    plt.close()

def getKdePlotZScoresplotKdeOverlayForDfList(df_kde, xAxis, yAxis):
    # hardcoded variable set up for plot limits
    xmin, xmax, ymin, ymax = 6, 12, -100, 100
    # create the kde grid (hardcoded 24 by 40)
    X, Y = np.mgrid[xmin:xmax:24j, ymin:ymax:40j]
    # get the x and y axes data to be plotted from the dataframe
    x = df_kde.loc[:, xAxis]
    y = df_kde.loc[:, yAxis]
    #Kernel Density Estimate Calculation
    positions = np.vstack([X.ravel(), Y.ravel()])
    values = np.vstack([x, y])
    kernel = stats.gaussian_kde(values)
    kernel.set_bandwidth(bw_method='silverman')
    # Z-scores: the part that actually plots the kde
    Z = np.reshape(kernel(positions).T, X.shape)
    return Z

if __name__ == '__main__':
    # read the files in as dataframes
    kdeDf = pd.read_csv(kdeFile)
    dataDf = pd.read_csv(dataFile)

    # only keep the unique sequence with best total energy
    df = dataDf.sort_values(by=['Total'], ascending=True)
    # keep only unique sequences, and the unique sequence with the lowest total energy
    df = df.drop_duplicates(subset=['Sequence'], keep='first')
    df = df[df['Total'] < 0]
    xAxis = 'endXShift'
    yAxis = 'endCrossingAngle'

    # plot the kde data
    plotGeomKde(kdeDf, df, 'Total', outputDir, xAxis, yAxis, reverseColormap=True)
    minY, maxY = 0, 1
    plotGeomKde(kdeDf, df, 'PercentGpA', outputDir, xAxis, yAxis, 1, minY, maxY)