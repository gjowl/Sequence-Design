# @Author: Gilbert Loiseau
# @Date:   2021-11-17
# @Filename: scriptToCopyPDBFilesByBin.py
# @Last modified by:   Gilbert Loiseau
# @Last modified time: 2021-11-17



#TODO: write a script that will read through the list of interfaces, then loop through each of the bin files,
# and output a small bash script to get the pdb files for each of those into a new directory (doesn't seem too hard, going to organize data and do this in the morning)


inputDir = "C:"

for i in interfaceList:
